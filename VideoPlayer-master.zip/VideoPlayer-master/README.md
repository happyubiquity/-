# 简单实用时尚好看的视频播放网页
简单的H5， 完全支持VTT字幕

## 项目截图

![](https://i.loli.net/2020/09/16/SxEnBe9rHVvhiA6.png)

